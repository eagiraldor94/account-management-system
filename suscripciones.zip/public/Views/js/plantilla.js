/*==================================
=            Data table            =
==================================*/

$(function () {
    $('.tabla').DataTable({
      "paging": true,
      "lengthChange": true,
      "searching": true,
      "ordering": true,
      "info": true,
      "autoWidth": true,
      "language": {
    		"sProcessing": 	"Procesando...",
    		"sLengthMenu": 	"Mostrar _MENU_ registros",
    		"sZeroRecords": "No se encontraron resultados",
    		"sEmptyTable": 	"Ningún dato disponible en esta tabla",
    		"sInfo": 		"Mostrando registros del _START_ al _END_ de un total de _TOTAL_",
    		"sInfoEmpty": 	"Mostrando registros del 0 al 0 de un total de 0",
    		"sInfoFiltered": "(filtrado de un total de _MAX_ registros)",
    		"sInfoPostFix": "",
    		"sSearch": 		"Buscar:",
    		"sUrl": 		"",
    		"sInfoThousands": ",",
    		"sLoadingRecords": "Cargando...",
    		"oPaginate": {
    			"sFirst": 	"Primero",
    			"sLast": 	"Último",
    			"sNext": 	"Siguiente",
    			"sPrevious": "Anterior"
    		},
    		"oAria": {
    			"sSortAscending": ": Activar para ordenar la columna de manera ascendente",
    			"sSortDescending": ": Activar para ordenar la columna de manera descendente",
    		}
    	}
    });
    
    $.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });

    var $_GET = {};

  document.location.search.replace(/\??(?:([^=]+)=([^&]*)&?)/g, function () {
      function decode(s) {
          return decodeURIComponent(s.split("+").join(" "));
      }

      $_GET[decode(arguments[1])] = decode(arguments[2]);
  });
  });

//iCheck for checkbox and radio inputs
$(function () {
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass   : 'iradio_minimal-blue'
    })
  });
    

//Flat red color scheme for iCheck

  $(function () {
        $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass   : 'iradio_flat-green'
    })
  });
  $(function () {
    // Data masks
      //Datemask dd/mm/yyyy
    $('#datemask').inputmask('dd/mm/yyyy', { 'placeholder': 'dd/mm/yyyy' })
    //Datemask2 mm/dd/yyyy
    $('#datemask2').inputmask('mm/dd/yyyy', { 'placeholder': 'mm/dd/yyyy' })
    //Money Euro
    $('[data-mask]').inputmask()
  });